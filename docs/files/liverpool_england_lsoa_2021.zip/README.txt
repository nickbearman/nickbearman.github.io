Files:
england_lsoa_2021.shp
england_lsoa_2021.shx
england_lsoa_2021.dbf
england_lsoa_2021.prj

Areas:
Liverpool

This data is provided with the support of the ESRC and JISC and uses boundary material which is copyright of the Crown, the Post Office and the ED-LINE consortium.