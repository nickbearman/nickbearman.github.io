Using Sound to Represent Spatial Data in ArcGIS 
===============================================
Nick Bearman and Peter F. Fisher
Department of Geography, University of Leicester, Leicester, LE1 7RH, UK
Weblink: http://www.nickbearman.me.uk/go/bearman_fisher_2011

This ZIP file contains the code and program from the above paper in Computers & Geosciences. See the paper for details on  
the reasoning and methodology used. The example data included in this zip file is different because the original data used  
in the evaluation is subject to copyright from the Ordnance Survey. The data included is from OS OpenData and USGS Landsat  
Archive. A video of the program using the original data set is available at http://www.nickbearman.me.uk/go/bearman_fisher_2011. 

A video of the demonstration data is also available at http://www.nickbearman.me.uk/go/bearman_fisher_2011. 

This was created in ArcGIS 9.2 and has also been tested in ArcGIS 9.3. It should work with 9.x and may work with other  
versions, but compatibility cannot be guaranteed. It has been tested in Windows XP and Vista. 

To use the program, open Map.mxd. 

To start the sound, click on the 'Sound' tool, on the custom toolbar next to the 'Select Elements' tool. Zoom to the  
relevant data set you are interested in (using either the bookmarks or right-click -> Zoom to layer) and right click on the  
map to open the options menu. Set the musical scale, layer required (for the height data) and when you want the sound to  
play. There are various options, as explained in the journal article. 

For more information, please see the website (http://www.nickbearman.me.uk/go/bearman_fisher_2011) or the journal article. 

I am very happy to received comments etc., and try to help with any technical issues with the example if you have them.  
Please email n.bearman@uea.ac.uk or nick@nickbearman.me.uk.
